# k8slab
<<<<<<< HEAD
setup your own k8s test lab using vagrant, virutalbox and ansible
=======
>>>>>>> upload all data
